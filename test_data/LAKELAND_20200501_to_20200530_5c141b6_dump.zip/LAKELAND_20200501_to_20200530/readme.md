## Field Day Open Game Data 
### Retrieved from https://fielddaylab.wisc.edu/opengamedata 
### These anonymous data are provided in service of future educational data mining research. 
### They are made available under the Creative Commons CCO 1.0 Universal license. 
### See https://creativecommons.org/publicdomain/zero/1.0/ 

## Suggested citation: 
### Field Day. (2019). Open Educational Game Play Logs - [dataset ID]. Retrieved [today's date] from https://fielddaylab.wisc.edu/opengamedata 

## Game: LAKELAND 

## Field Descriptions: 
### Raw CSV Columns:
id - Unique identifier for a row
app_id - A string identifying which game from which the event came
app_id_fast - A second version of the app id, to be removed
app_version - The version of the game from which the event came
sess_id - Unique identifier for the gameplay sess
persistent_sess_id - Unique identifier across all gameplay sesss from a single computer
player_id - A custom, per-player ID, only exists if player entered an ID on one of our custom portal pages, else null
level - The game level in which the event was logged
event - The type of event logged
event_custom - A number corresponding to the game-specific event type for events labeled 'Custom'
event_data_simple - Unused (always=0), to be deleted
event_data_complex - Data specific to an event type, encoded as a JSON string
client_time - The client machine time when the event was generated, 1 second resolution
client_secs_ms - Client time milliseconds
server_time - The server machine time when the event was logged
remote_addr - The IP address for the player's computer
req_id - Another ID of some kind, to be removed
sess_n - Counter of events in the sess, from 0. A row with sess_n = i is the (i+1)-th event of the sess
http_user_agent - Data on the type of web browser, OS, etc. in use by the player

### Processed Features:
EventCount - Number of player events in the given level
ActiveEventCount - Number of player events that require the player's active input
InactiveEventCount - Number of game events that don't require the player's active input
durationInSecs - Time (in seconds) spent on the given level
count_gamestate_logs - count of gamestate logs
count_achievements - Player feature - Progress: count of achievements
count_explore_events - number of events that explore the gamestate: SELECTTILE, SELECTFARMBIT, SELECTITEM, TOGGLEACHIEVEMENTS, TOGGLESHOP
count_impact_events - number of active events that change the gamestate: BUY,TILEUSESELECT,ITEMUSESELECT
count_idle - number of times the player went from active to idle
count_buy_home - Player feature - Number of times the player: buy a home
count_buy_food - Player feature - Number of times the player: buy a food
count_buy_farm - Player feature - Number of times the player: buy a farm
count_buy_fertilizer - Player feature - Number of times the player: buy a fertilizer
count_buy_livestock - Player feature - Number of times the player: buy a livestock
count_buy_skimmer - Player feature - Number of times the player: buy a skimmer
count_buy_sign - Player feature - Number of times the player: buy a sign
count_buy_road - Player feature - Number of times the player: buy a road
money_spent - Player feature - General: money spent
money_spent_home - Player feature - General: money spent on home
money_spent_food - Player feature - General: money spent on food
money_spent_farm - Player feature - General: money spent on farm
money_spent_fertilizer - Player feature - General: money spent on fertilizer
money_spent_livestock - Player feature - General: money spent on livestock
money_spent_skimmer - Player feature - General: money spent on skimmer
money_spent_sign - Player feature - General: money spent on sign
money_spent_road - Player feature - General: money spent on road
min_num_home_in_play - Player feature - General: min number of home in play
max_num_home_in_play - Player feature - General: max number of home in play
min_num_food_in_play - Player feature - General: min number of food in play
max_num_food_in_play - Player feature - General: max number of food in play
min_num_farm_in_play - Player feature - General: min number of farm in play
max_num_farm_in_play - Player feature - General: max number of farm in play
min_num_fertilizer_in_play - Player feature - General: min number of fertilizer in play
max_num_fertilizer_in_play - Player feature - General: max number of fertilizer in play
min_num_livestock_in_play - Player feature - General: min number of livestock in play
max_num_livestock_in_play - Player feature - General: max number of livestock in play
min_num_skimmer_in_play - Player feature - General: min number of skimmer in play
max_num_skimmer_in_play - Player feature - General: max number of skimmer in play
min_num_sign_in_play - Player feature - General: min number of sign in play
max_num_sign_in_play - Player feature - General: max number of sign in play
min_num_road_in_play - Player feature - General: min number of road in play
max_num_road_in_play - Player feature - General: max number of road in play
min_num_water_in_play - Player feature - General: min number of water in play
max_num_water_in_play - Player feature - General: max number of water in play
min_num_poop_in_play - Player feature - General: min number of poop in play
max_num_poop_in_play - Player feature - General: max number of poop in play
min_num_milk_in_play - Player feature - General: min number of milk in play
max_num_milk_in_play - Player feature - General: max number of milk in play
avg_num_tiles_hovered_before_placing_home - Player feature - General: ave num tiles hovered before placing home
avg_num_tiles_hovered_before_placing_food - Player feature - General: ave num tiles hovered before placing food
avg_num_tiles_hovered_before_placing_farm - Player feature - General: ave num tiles hovered before placing farm
avg_num_tiles_hovered_before_placing_fertilizer - Player feature - General: ave num tiles hovered before placing fertilizer
avg_num_tiles_hovered_before_placing_livestock - Player feature - General: ave num tiles hovered before placing livestock
avg_num_tiles_hovered_before_placing_skimmer - Player feature - General: ave num tiles hovered before placing skimmer
avg_num_tiles_hovered_before_placing_sign - Player feature - General: ave num tiles hovered before placing sign
avg_num_tiles_hovered_before_placing_road - Player feature - General: ave num tiles hovered before placing (the first) road
avg_distance_between_poop_placement_and_lake - Player feature - Assessment: average distance between poop placement and lake
avg_avg_distance_between_buildings - Player feature - Assessment: Average distance between buildings (when they build, how far is it from the closest thing)
percent_building_a_farm_on_highest_nutrition_tile - Player feature - General: percent building a farm on the best tile with the highest nutrition that was hovered over during the buy process
percent_placing_fertilizer_on_lowest_nutrient_farm -  TODO:::figure out how to calculate this:::TODO Player feature - General: percent placing fertilizer on lowest nutrient farm
build_sequences - Player feature - General: Build Sequences (as binary columns if they exist)[Home, Farm, Farm, Farm],[Home, Farm, Home, Farm], Etc.
count_inspect_tile - Player feature - Number of times the player: inspect a tile
count_open_achievements - Player feature - Number of times the player: look at achievements
count_open_shop - Player feature - Number of times the player: open the shop
count_deaths - Game feature - General: num deaths per sess
count_rains - Count of how many times it rained
count_encounter_tutorial - Player feature - Number of times the player: encounter a tutorial
count_skips - Player feature - Number of times the player: press skip button
time_in_nutrition_view - Player feature - Total amount of time the player: spend in nutrition view
time_in_game_speed_pause - Player feature - Total amount of time the player: in game speed pause (with client identified to correct for fps) 
time_in_game_speed_play - Player feature - Total amount of time the player: in game speed play (with client identified to correct for fps) 
time_in_game_speed_fast - Player feature - Total amount of time the player: in game speed fast (with client identified to correct for fps) 
time_in_game_speed_vfast - Player feature - Total amount of time the player: in game speed vfast (with client identified to correct for fps) 
time_idle - Amount of time in gameplay spent idle (time past IDLE_THRESH_SECONDS without active log)
time_active - Amount of time in gameplay spent actively playing (not going more than IDLE_THRESH_SECONDS without an active event, including IDLE_THRESH_SECONDS if gone inactive)
count_change_item_mark - Player feature - Number of times the player: change a sale/eat/feed state in an item panel
count_change_tile_mark - Player feature - Number of times the player: change a sale/eat/feed state in a farm panel
max_num_food_marked_sell - Player feature - General: percent of food marked for sale
max_num_food_marked_use - Player feature - General: percent of food marked for eat
max_num_food_marked_feed - Player feature - General: percent of food marked for feed
max_num_milk_marked_sell - Player feature - General: percent of milk marked for sale
max_num_milk_marked_use - Player feature - General: percent of milk marked for eat
max_num_poop_marked_sell - Player feature - General: percent of poop marked for sale
max_num_poop_marked_use - Player feature - General: percent of poop marked for fertilize
max_percent_food_marked_sell - Player feature - General: percent of food marked for sale
max_percent_food_marked_use - Player feature - General: percent of food marked for eat
max_percent_food_marked_feed - Player feature - General: percent of food marked for feed
max_percent_milk_marked_sell - Player feature - General: percent of milk marked for sale
max_percent_milk_marked_use - Player feature - General: percent of milk marked for eat
max_percent_poop_marked_sell - Player feature - General: percent of poop marked for sale
max_percent_poop_marked_use - Player feature - General: percent of poop marked for fertilize
min_num_food_marked_sell - Player feature - General: percent of food marked for sale
min_num_food_marked_use - Player feature - General: percent of food marked for eat
min_num_food_marked_feed - Player feature - General: percent of food marked for feed
min_num_milk_marked_sell - Player feature - General: percent of milk marked for sale
min_num_milk_marked_use - Player feature - General: percent of milk marked for eat
min_num_poop_marked_sell - Player feature - General: percent of poop marked for sale
min_num_poop_marked_use - Player feature - General: percent of poop marked for fertilize
min_percent_food_marked_sell - Player feature - General: percent of food marked for sale
min_percent_food_marked_use - Player feature - General: percent of food marked for eat
min_percent_food_marked_feed - Player feature - General: percent of food marked for feed
min_percent_milk_marked_sell - Player feature - General: percent of milk marked for sale
min_percent_milk_marked_use - Player feature - General: percent of milk marked for eat
min_percent_poop_marked_sell - Player feature - General: percent of poop marked for sale
min_percent_poop_marked_use - Player feature - General: percent of poop marked for fertilize
max_num_per_capita_food_marked_sell - Player feature - General: maximum per capita number of food marked for sale
min_num_per_capita_food_marked_sell - Player feature - General: minimum per capita number of food marked for sale
max_num_per_capita_food_marked_use - Player feature - General: maximum per capita number of food marked for eat
min_num_per_capita_food_marked_use - Player feature - General: minimum per capita number of food marked for eat
max_num_per_capita_food_marked_feed - Player feature - General: maximum per capita number of food marked for feed
min_num_per_capita_food_marked_feed - Player feature - General: minimum per capita number of food marked for feed
max_num_per_capita_milk_marked_sell - Player feature - General: maximum per capita number of milk marked for sale
min_num_per_capita_milk_marked_sell - Player feature - General: minimum per capita number of milk marked for sale
max_num_per_capita_milk_marked_use - Player feature - General: maximum per capita number of milk marked for eat
min_num_per_capita_milk_marked_use - Player feature - General: minimum per capita number of milk marked for eat
max_num_per_capita_poop_marked_sell - Player feature - General: maximum per capita number of poop marked for sale
min_num_per_capita_poop_marked_sell - Player feature - General: minimum per capita number of poop marked for sale
max_num_per_capita_poop_marked_use - Player feature - General: maximum per capita number of poop marked for fertilize
min_num_per_capita_poop_marked_use - Player feature - General: minimum per capita number of poop marked for fertilize
count_fullness_motivated_txt_emotes_per_capita - Game feature - General: max num of the fullness_motivated emotes per capita
count_fullness_desperate_txt_emotes_per_capita - Game feature - General: max num of the fullness_desperate emotes per capita
count_energy_desperate_txt_emotes_per_capita - Game feature - General: max num of the energy_desperate emotes per capita
count_joy_motivated_txt_emotes_per_capita - Game feature - General: max num of the joy_motivated emotes per capita
count_joy_desperate_txt_emotes_per_capita - Game feature - General: max num of the joy_desperate emotes per capita
count_puke_txt_emotes_per_capita - Game feature - General: max num of the puke emotes per capita
count_yum_txt_emotes_per_capita - Game feature - General: max num of the yum emotes per capita
count_tired_txt_emotes_per_capita - Game feature - General: max num of the tired emotes per capita
count_happy_txt_emotes_per_capita - Game feature - General: max num of the happy emotes per capita
count_swim_txt_emotes_per_capita - Game feature - General: max num of the swim emotes per capita
count_sale_txt_emotes_per_capita - Game feature - General: max num of the sale emotes per capita
percent_positive_emotes - Game feature - General: percent positive emotes
percent_negative_emotes - Game feature - General: percent negative emotes
percent_neutral_emotes - Game feature - General: percent neutral emotes
money_earned - Game feature - General: money earned
total_positive_emotes - Game feature - General: total positive emotes
total_negative_emotes - Game feature - General: percent negative emotes
total_neutral_emotes - Game feature - General: percent neutral emotes
max_avg_lake_nutrition - Game feature - General: ave lake nutrition
min_avg_lake_nutrition - Game feature - General: ave lake nutrition
count_farmfails - Count of farms going into low productivity (nutrition roughly < 1%)
count_blooms - Count of blooms
count_food_produced - Game feature - General: num of food produced
count_milk_produced - Game feature - General: num of milk produced
count_poop_produced - Game feature - General: num of poop produced
sess_count_achievements - Player feature - Progress: count of achievements
sess_count_encounter_tutorial - Player feature - Progress: count of tutorials
sess_count_skips - Player feature - Progress: count of skips
sess_count_gamestate_logs - count of gamestate logs
sess_count_rains - Count of how many times it rained
sess_count_explore_events - number of events that explore the gamestate: SELECTTILE, SELECTFARMBIT, SELECTITEM, TOGGLEACHIEVEMENTS, TOGGLESHOP
sess_count_impact_events - number of active events that change the gamestate: BUY,TILEUSESELECT,ITEMUSESELECT
sess_count_idle - number of times the player went from active to idle
sess_count_buy_home - Player feature - Number of times the player: buy a home
sess_count_buy_food - Player feature - Number of times the player: buy a food
sess_count_buy_farm - Player feature - Number of times the player: buy a farm
sess_count_buy_fertilizer - Player feature - Number of times the player: buy a fertilizer
sess_count_buy_livestock - Player feature - Number of times the player: buy a livestock
sess_count_buy_skimmer - Player feature - Number of times the player: buy a skimmer
sess_count_buy_sign - Player feature - Number of times the player: buy a sign
sess_count_buy_road - Player feature - Number of times the player: buy a road
sess_money_spent_home - Player feature - General: money spent on home
sess_money_spent_food - Player feature - General: money spent on food
sess_money_spent_farm - Player feature - General: money spent on farm
sess_money_spent_fertilizer - Player feature - General: money spent on fertilizer
sess_money_spent_livestock - Player feature - General: money spent on livestock
sess_money_spent_skimmer - Player feature - General: money spent on skimmer
sess_money_spent_sign - Player feature - General: money spent on sign
sess_money_spent_road - Player feature - General: money spent on road
sess_count_change_item_mark - Player feature - Number of times the player: change a sale/eat/feed state in an item panel
sess_count_change_tile_mark - Player feature - Number of times the player: change a sale/eat/feed state in a farm panel
sess_time_to_exist_achievement - Player feature - Progress: Time to the exist achievement (or 0 if not achieved)
sess_time_to_group_achievement - Player feature - Progress: Time to the group achievement (or 0 if not achieved)
sess_time_to_town_achievement - Player feature - Progress: Time to the town achievement (or 0 if not achieved)
sess_time_to_city_achievement - Player feature - Progress: Time to the city achievement (or 0 if not achieved)
sess_time_to_farmer_achievement - Player feature - Progress: Time to the farmer achievement (or 0 if not achieved)
sess_time_to_farmers_achievement - Player feature - Progress: Time to the farmers achievement (or 0 if not achieved)
sess_time_to_farmtown_achievement - Player feature - Progress: Time to the farmtown achievement (or 0 if not achieved)
sess_time_to_megafarm_achievement - Player feature - Progress: Time to the megafarm achievement (or 0 if not achieved)
sess_time_to_paycheck_achievement - Player feature - Progress: Time to the paycheck achievement (or 0 if not achieved)
sess_time_to_thousandair_achievement - Player feature - Progress: Time to the thousandair achievement (or 0 if not achieved)
sess_time_to_stability_achievement - Player feature - Progress: Time to the stability achievement (or 0 if not achieved)
sess_time_to_riches_achievement - Player feature - Progress: Time to the riches achievement (or 0 if not achieved)
sess_time_to_bloom_achievement - Player feature - Progress: Time to the bloom achievement (or 0 if not achieved)
sess_time_to_bigbloom_achievement - Player feature - Progress: Time to the bigbloom achievement (or 0 if not achieved)
sess_time_to_hugebloom_achievement - Player feature - Progress: Time to the hugebloom achievement (or 0 if not achieved)
sess_time_to_massivebloom_achievement - Player feature - Progress: Time to the massivebloom achievement (or 0 if not achieved)
sess_time_to_another_death_tutorial - Player feature - Progress: Time to another_death tutorial (or 0 if unencountered)
sess_time_to_another_member_tutorial - Player feature - Progress: Time to another_member tutorial (or 0 if unencountered)
sess_time_to_bloom_tutorial - Player feature - Progress: Time to bloom tutorial (or 0 if unencountered)
sess_time_to_build_a_farm_tutorial - Player feature - Progress: Time to build_a_farm tutorial (or 0 if unencountered)
sess_time_to_build_a_house_tutorial - Player feature - Progress: Time to build_a_house tutorial (or 0 if unencountered)
sess_time_to_buy_fertilizer_tutorial - Player feature - Progress: Time to buy_fertilizer tutorial (or 0 if unencountered)
sess_time_to_buy_food_tutorial - Player feature - Progress: Time to buy_food tutorial (or 0 if unencountered)
sess_time_to_buy_livestock_tutorial - Player feature - Progress: Time to buy_livestock tutorial (or 0 if unencountered)
sess_time_to_death_tutorial - Player feature - Progress: Time to death tutorial (or 0 if unencountered)
sess_time_to_end_life_tutorial - Player feature - Progress: Time to end_life tutorial (or 0 if unencountered)
sess_time_to_extra_life_tutorial - Player feature - Progress: Time to extra_life tutorial (or 0 if unencountered)
sess_time_to_final_death_tutorial - Player feature - Progress: Time to final_death tutorial (or 0 if unencountered)
sess_time_to_flooded_fertilizer_tutorial - Player feature - Progress: Time to flooded_fertilizer tutorial (or 0 if unencountered)
sess_time_to_gross_tutorial - Player feature - Progress: Time to gross tutorial (or 0 if unencountered)
sess_time_to_gross_again_tutorial - Player feature - Progress: Time to gross_again tutorial (or 0 if unencountered)
sess_time_to_livestock_tutorial - Player feature - Progress: Time to livestock tutorial (or 0 if unencountered)
sess_time_to_long_travel_tutorial - Player feature - Progress: Time to long_travel tutorial (or 0 if unencountered)
sess_time_to_low_nutrients_tutorial - Player feature - Progress: Time to low_nutrients tutorial (or 0 if unencountered)
sess_time_to_mass_sadness_tutorial - Player feature - Progress: Time to mass_sadness tutorial (or 0 if unencountered)
sess_time_to_poop_tutorial - Player feature - Progress: Time to poop tutorial (or 0 if unencountered)
sess_time_to_rain_tutorial - Player feature - Progress: Time to rain tutorial (or 0 if unencountered)
sess_time_to_sell_food_tutorial - Player feature - Progress: Time to sell_food tutorial (or 0 if unencountered)
sess_time_to_successful_harvest_tutorial - Player feature - Progress: Time to successful_harvest tutorial (or 0 if unencountered)
sess_time_to_timewarp_tutorial - Player feature - Progress: Time to timewarp tutorial (or 0 if unencountered)
sess_time_to_unattended_farm_tutorial - Player feature - Progress: Time to unattended_farm tutorial (or 0 if unencountered)
sess_time_to_unused_fertilizer_tutorial - Player feature - Progress: Time to unused_fertilizer tutorial (or 0 if unencountered)
sess_time_to_first_rain - Time to the first rain the player experienced
sess_avg_num_tiles_hovered_before_placing_home - Player feature - General: ave num tiles hovered before placing home
sess_avg_num_tiles_hovered_before_placing_food - Player feature - General: ave num tiles hovered before placing food
sess_avg_num_tiles_hovered_before_placing_farm - Player feature - General: ave num tiles hovered before placing farm
sess_avg_num_tiles_hovered_before_placing_fertilizer - Player feature - General: ave num tiles hovered before placing fertilizer
sess_avg_num_tiles_hovered_before_placing_livestock - Player feature - General: ave num tiles hovered before placing livestock
sess_avg_num_tiles_hovered_before_placing_skimmer - Player feature - General: ave num tiles hovered before placing skimmer
sess_avg_num_tiles_hovered_before_placing_sign - Player feature - General: ave num tiles hovered before placing sign
sess_avg_num_tiles_hovered_before_placing_road - Player feature - General: ave num tiles hovered before placing (the first) road
sess_avg_time_per_blurb_in_another_death_tutorial - Player feature - Progress: Time to another_death tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_another_member_tutorial - Player feature - Progress: Time to another_member tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_bloom_tutorial - Player feature - Progress: Time to bloom tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_build_a_farm_tutorial - Player feature - Progress: Time to build_a_farm tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_build_a_house_tutorial - Player feature - Progress: Time to build_a_house tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_buy_fertilizer_tutorial - Player feature - Progress: Time to buy_fertilizer tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_buy_food_tutorial - Player feature - Progress: Time to buy_food tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_buy_livestock_tutorial - Player feature - Progress: Time to buy_livestock tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_death_tutorial - Player feature - Progress: Time to death tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_end_life_tutorial - Player feature - Progress: Time to end_life tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_extra_life_tutorial - Player feature - Progress: Time to extra_life tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_final_death_tutorial - Player feature - Progress: Time to final_death tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_flooded_fertilizer_tutorial - Player feature - Progress: Time to flooded_fertilizer tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_gross_tutorial - Player feature - Progress: Time to gross tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_gross_again_tutorial - Player feature - Progress: Time to gross_again tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_livestock_tutorial - Player feature - Progress: Time to livestock tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_long_travel_tutorial - Player feature - Progress: Time to long_travel tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_low_nutrients_tutorial - Player feature - Progress: Time to low_nutrients tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_mass_sadness_tutorial - Player feature - Progress: Time to mass_sadness tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_poop_tutorial - Player feature - Progress: Time to poop tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_rain_tutorial - Player feature - Progress: Time to rain tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_sell_food_tutorial - Player feature - Progress: Time to sell_food tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_successful_harvest_tutorial - Player feature - Progress: Time to successful_harvest tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_timewarp_tutorial - Player feature - Progress: Time to timewarp tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_unattended_farm_tutorial - Player feature - Progress: Time to unattended_farm tutorial (or 0 if unencountered)
sess_avg_time_per_blurb_in_unused_fertilizer_tutorial - Player feature - Progress: Time to unused_fertilizer tutorial (or 0 if unencountered)
sess_time_to_first_home - Player feature - Progress: Time to first home
sess_time_to_first_food - Player feature - Progress: Time to first food
sess_time_to_first_farm - Player feature - Progress: Time to first farm
sess_time_to_first_fertilizer - Player feature - Progress: Time to first fertilizer
sess_time_to_first_livestock - Player feature - Progress: Time to first livestock
sess_time_to_first_skimmer - Player feature - Progress: Time to first skimmer
sess_time_to_first_sign - Player feature - Progress: Time to first sign
sess_time_to_first_road - Player feature - Progress: Time to first road
sess_avg_time_per_blurb - ? include skips ? Player feature - General: ave time per tutorial screen (blurb) before continue
sess_count_food_produced - Game feature - General: num of food produced
sess_count_milk_produced - Game feature - General: num of milk produced
sess_count_poop_produced - Game feature - General: num of poop produced
sess_money_earned - Game feature - General: money earned
sess_money_spent - Game feature - General: money earned
sess_time_in_nutrition_view - Player feature - Total amount of time the player: spend in nutrition view
sess_time_in_game_speed_pause - Player feature - Total amount of time the player: in game speed pause (with client identified to correct for fps) 
sess_time_in_game_speed_play - Player feature - Total amount of time the player: in game speed play (with client identified to correct for fps) 
sess_time_in_game_speed_fast - Player feature - Total amount of time the player: in game speed fast (with client identified to correct for fps) 
sess_time_in_game_speed_vfast - Player feature - Total amount of time the player: in game speed vfast (with client identified to correct for fps) 
sess_time_idle - Amount of time in gameplay spent idle (time past IDLE_THRESH_SECONDS without active log)
sess_time_active - Amount of time in gameplay spent actively playing (not going more than IDLE_THRESH_SECONDS without an active event, including IDLE_THRESH_SECONDS if gone inactive)
sess_max_num_per_capita_food_marked_sell - Player feature - General: maximum per capita number of food marked for sale
sess_max_num_per_capita_food_marked_use - Player feature - General: maximum per capita number of food marked for eat
sess_max_num_per_capita_food_marked_feed - Player feature - General: maximum per capita number of food marked for feed
sess_max_num_per_capita_milk_marked_sell - Player feature - General: maximum per capita number of milk marked for sale
sess_max_num_per_capita_milk_marked_use - Player feature - General: maximum per capita number of milk marked for eat
sess_max_num_per_capita_poop_marked_sell - Player feature - General: maximum per capita number of poop marked for sale
sess_max_num_per_capita_poop_marked_use - Player feature - General: maximum per capita number of poop marked for fertilize
sess_min_num_per_capita_food_marked_sell - Player feature - General: minimum per capita number of food marked for sale
sess_min_num_per_capita_food_marked_use - Player feature - General: minimum per capita number of food marked for eat
sess_min_num_per_capita_food_marked_feed - Player feature - General: minimum per capita number of food marked for feed
sess_min_num_per_capita_milk_marked_sell - Player feature - General: minimum per capita number of milk marked for sale
sess_min_num_per_capita_milk_marked_use - Player feature - General: minimum per capita number of milk marked for eat
sess_min_num_per_capita_poop_marked_sell - Player feature - General: minimum per capita number of poop marked for sale
sess_min_num_per_capita_poop_marked_use - Player feature - General: minimum per capita number of poop marked for fertilize
sess_max_num_food_marked_sell - Player feature - General: percent of food marked for sale
sess_max_num_food_marked_use - Player feature - General: percent of food marked for eat
sess_max_num_food_marked_feed - Player feature - General: percent of food marked for feed
sess_max_num_milk_marked_sell - Player feature - General: percent of milk marked for sale
sess_max_num_milk_marked_use - Player feature - General: percent of milk marked for eat
sess_max_num_poop_marked_sell - Player feature - General: percent of poop marked for sale
sess_max_num_poop_marked_use - Player feature - General: percent of poop marked for fertilize
sess_max_percent_food_marked_sell - Player feature - General: percent of food marked for sale
sess_max_percent_food_marked_use - Player feature - General: percent of food marked for eat
sess_max_percent_food_marked_feed - Player feature - General: percent of food marked for feed
sess_max_percent_milk_marked_sell - Player feature - General: percent of milk marked for sale
sess_max_percent_milk_marked_use - Player feature - General: percent of milk marked for eat
sess_max_percent_poop_marked_sell - Player feature - General: percent of poop marked for sale
sess_max_percent_poop_marked_use - Player feature - General: percent of poop marked for fertilize
sess_min_num_food_marked_sell - Player feature - General: percent of food marked for sale
sess_min_num_food_marked_use - Player feature - General: percent of food marked for eat
sess_min_num_food_marked_feed - Player feature - General: percent of food marked for feed
sess_min_num_milk_marked_sell - Player feature - General: percent of milk marked for sale
sess_min_num_milk_marked_use - Player feature - General: percent of milk marked for eat
sess_min_num_poop_marked_sell - Player feature - General: percent of poop marked for sale
sess_min_num_poop_marked_use - Player feature - General: percent of poop marked for fertilize
sess_min_percent_food_marked_sell - Player feature - General: percent of food marked for sale
sess_min_percent_food_marked_use - Player feature - General: percent of food marked for eat
sess_min_percent_food_marked_feed - Player feature - General: percent of food marked for feed
sess_min_percent_milk_marked_sell - Player feature - General: percent of milk marked for sale
sess_min_percent_milk_marked_use - Player feature - General: percent of milk marked for eat
sess_min_percent_poop_marked_sell - Player feature - General: percent of poop marked for sale
sess_min_percent_poop_marked_use - Player feature - General: percent of poop marked for fertilize
sess_min_num_home_in_play - Player feature - General: min number of home in play
sess_max_num_home_in_play - Player feature - General: max number of home in play
sess_min_num_food_in_play - Player feature - General: min number of food in play
sess_max_num_food_in_play - Player feature - General: max number of food in play
sess_min_num_farm_in_play - Player feature - General: min number of farm in play
sess_max_num_farm_in_play - Player feature - General: max number of farm in play
sess_min_num_fertilizer_in_play - Player feature - General: min number of fertilizer in play
sess_max_num_fertilizer_in_play - Player feature - General: max number of fertilizer in play
sess_min_num_livestock_in_play - Player feature - General: min number of livestock in play
sess_max_num_livestock_in_play - Player feature - General: max number of livestock in play
sess_min_num_skimmer_in_play - Player feature - General: min number of skimmer in play
sess_max_num_skimmer_in_play - Player feature - General: max number of skimmer in play
sess_min_num_sign_in_play - Player feature - General: min number of sign in play
sess_max_num_sign_in_play - Player feature - General: max number of sign in play
sess_min_num_road_in_play - Player feature - General: min number of road in play
sess_max_num_road_in_play - Player feature - General: max number of road in play
sess_min_num_water_in_play - Player feature - General: min number of water in play
sess_max_num_water_in_play - Player feature - General: max number of water in play
sess_min_num_poop_in_play - Player feature - General: min number of poop in play
sess_max_num_poop_in_play - Player feature - General: max number of poop in play
sess_min_num_milk_in_play - Player feature - General: min number of milk in play
sess_max_num_milk_in_play - Player feature - General: max number of milk in play
sess_count_fullness_motivated_txt_emotes_per_capita - Game feature - General: max num of the fullness_motivated emotes per capita
sess_count_fullness_desperate_txt_emotes_per_capita - Game feature - General: max num of the fullness_desperate emotes per capita
sess_count_energy_desperate_txt_emotes_per_capita - Game feature - General: max num of the energy_desperate emotes per capita
sess_count_joy_motivated_txt_emotes_per_capita - Game feature - General: max num of the joy_motivated emotes per capita
sess_count_joy_desperate_txt_emotes_per_capita - Game feature - General: max num of the joy_desperate emotes per capita
sess_count_puke_txt_emotes_per_capita - Game feature - General: max num of the puke emotes per capita
sess_count_yum_txt_emotes_per_capita - Game feature - General: max num of the yum emotes per capita
sess_count_tired_txt_emotes_per_capita - Game feature - General: max num of the tired emotes per capita
sess_count_happy_txt_emotes_per_capita - Game feature - General: max num of the happy emotes per capita
sess_count_swim_txt_emotes_per_capita - Game feature - General: max num of the swim emotes per capita
sess_count_sale_txt_emotes_per_capita - Game feature - General: max num of the sale emotes per capita
sess_percent_positive_emotes - Game feature - General: percent positive emotes
sess_percent_negative_emotes - Game feature - General: percent negative emotes
sess_percent_neutral_emotes - Game feature - General: percent neutral emotes
sess_total_positive_emotes - Game feature - General: total positive emotes
sess_total_negative_emotes - Game feature - General: total negative emotes
sess_total_neutral_emotes - Game feature - General: total neutral emotes
sess_avg_distance_between_poop_placement_and_lake -  Player feature - Assessment: average distance between poop placement and lake
sess_avg_avg_distance_between_buildings - Player feature - Assessment: Average distance between buildings (when they build, how far is it from the closest thing)
sess_count_farmfails - Count of farms going into low productivity (nutrition roughly < 1%)
sess_max_avg_lake_nutrition - Game feature - General: ave lake nutrition
sess_min_avg_lake_nutrition - Game feature - General: ave lake nutrition
sess_count_blooms - Count of algae blooms
sess_count_inspect_tile - Player feature - Number of times the player: inspect a tile
sess_count_open_achievements - Player feature - Number of times the player: look at achievements
sess_count_open_shop - Player feature - Number of times the player: open the shop
sess_count_deaths - Game feature - General: num deaths per sess
event_sequence - Sequence of buys, deaths, blooms in the game
sess_percent_building_a_farm_on_highest_nutrition_tile - Player feature - General: percent building a farm on the best tile with the highest nutrition that was hovered over during the buy process
sess_percent_placing_fertilizer_on_lowest_nutrient_farm -  TODO:::figure out how to calculate this:::TODO Player feature - General: percent placing fertilizer on lowest nutrient farm
sess_EventCount - The total number of events across the entire sess
sess_ActiveEventCount - Number of player events that require the player's active input
sess_InactiveEventCount - Number of game events that don't require the player's active input
play_year - year started the game (UTC)
play_month - month started the game (UTC)
play_day - day started the game (UTC)
play_hour - hour started the game (UTC)
play_minute - minute started the game (UTC)
play_second - second started the game (UTC)
rt_currently_active - (boolean - 1/0) whether or not the player is currently active
continue - 1 if player continued, 0 if new game
language - language name
audio - 1 if audio on, 0 if off
fullscreen - 1 if fullscreen, 0 if not
version - version number
debug - 1 if player used a debug feature, 0 if not
num_play - Playthrough number (i.e., if a player has died and restarts, this number will be 1 in the first playthrough and 2 in the second)
sessID - The player's sess ID number for this play sess
persistentSessionID - The sess ID for the player's device, persists across multiple players using the same device.
sessDuration - The total time (in seconds) spent over the entire sess
player_id - Player ID

## Data Logging Info:
See https://github.com/fielddaylab/usda/blob/master/README.md

Lakeland "levels" (features with the prefix lvln_, where n is a nonnegative integer) are realtime windows defined in the lakeland schema's config subobject. 
Level windows are "WINDOW_SIZE_SECONDS" (currently 300s) long, with each subsequent level starting "WINDOW_OVERLAP_SECONDS" (currently 30s) before the previous level ends. Lastly, because this theoretically could give infinite levels, "MAX_SESSION_SECONDS" (currently 2700s) is defined to stop taking logs after a given number of seconds.

Thus the current levels are as follows (as of 7/29/2020):
lvl0: 0s-300s (0:00-5:00)
lvl1: 270s-570s (4:30-9:30)
lvl2: 540s-840s (9:00-14:00)
lvl3: 810s-1110s
lvl4: 1080s-1380s
lvl5: 1350s-1650s
lvl6: 1620s-1920s
lvl7: 1890s-2190s
lvl8: 2160s-2460s
lvl9: 2430s-2700s (40:30-45:00)

## Global Database Changelog:
### July 2019:
- Crystal game data now includes Menu Button events.
### August 2019:
- Added remote_addr field to raw csv
- Duplicated events may exist in data prior to August 21, 2019.